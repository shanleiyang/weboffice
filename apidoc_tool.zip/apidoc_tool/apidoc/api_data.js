define({ "api": [
  {
    "type": "post",
    "url": "/app/getAnnouncementById",
    "title": "获取公告&申报项目信息详情",
    "version": "0.1.0",
    "name": "getAnnouncementById",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取公告&amp;申报项目信息详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "project_id",
            "description": "<p>公告&amp;申报项目id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "apply_id",
            "description": "<p>公告&amp;申报项目申请id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>公告&amp;申报项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>公告&amp;申报项目信息展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>公告&amp;申报项目信息字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getApproveCountByUserId",
    "title": "获取当前用户的所有审批数量",
    "version": "0.1.0",
    "name": "getApproveCountByUserId",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取当前用户的所有审批数量</p>",
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "data",
            "description": "<p>当前用户的所有审批数量</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getMajorInfoById",
    "title": "获取重大异常项目详情",
    "version": "0.1.0",
    "name": "getMajorInfoById",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取重大异常项目详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "major_project_id",
            "description": "<p>重大异常项目id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>重大异常项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>重大异常项目信息展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>重大异常项目信息字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getProjectInfoById",
    "title": "获取立项项目详情",
    "version": "0.1.0",
    "name": "getProjectInfoById",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取立项项目详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "project_id",
            "description": "<p>立项项目id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>立项项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>立项展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>立项展示字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getProtocolInfoById",
    "title": "获取协议盖章项目详情",
    "version": "0.1.0",
    "name": "getProtocolInfoById",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取协议盖章项目详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "project_id",
            "description": "<p>立项项目id</p>"
          },
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "protocol_id",
            "description": "<p>协议盖章id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>协议盖章项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>协议盖章展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>协议盖章字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getQualityDetail",
    "title": "获取质评项目详情",
    "version": "0.1.0",
    "name": "getQualityDetail",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取质评项目详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "quality_id",
            "description": "<p>质评id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>质评项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>质评信息展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>质评信息字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getQualityVoteInfo",
    "title": "获取某个质评项目投票详情",
    "version": "0.1.0",
    "name": "getQualityVoteInfo",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取某个质评项目投票详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "vote_basic_id",
            "description": "<p>投票任务id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>投票详情</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getSingleCoreDetail",
    "title": "获取内核投票详情",
    "version": "0.1.0",
    "name": "getSingleCoreDetail",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取内核投票详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "vote_basic_id",
            "description": "<p>投票任务id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>投票详情</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getSupervisionInfoById",
    "title": "获取督导项目详情",
    "version": "0.1.0",
    "name": "getSupervisionInfoById",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取督导项目详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "supervision_report_id",
            "description": "<p>督导项目id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>督导项目信息</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "fileds",
            "description": "<p>督导项目信息展示字段</p>"
          },
          {
            "group": "Success 200",
            "type": "Map",
            "optional": false,
            "field": "order",
            "description": "<p>督导项目信息字段排序号</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  },
  {
    "type": "post",
    "url": "/app/getVoteInfo",
    "title": "获取立项项目投票详情",
    "version": "0.1.0",
    "name": "getVoteInfo",
    "group": "App",
    "permission": [
      {
        "name": "none"
      }
    ],
    "description": "<p>获取立项项目投票详情</p>",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "int",
            "optional": false,
            "field": "vote_basic_id",
            "description": "<p>投票任务id</p>"
          }
        ]
      }
    },
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "type": "Record",
            "optional": false,
            "field": "data",
            "description": "<p>投票详情</p>"
          }
        ]
      }
    },
    "filename": "./AppLoadDataController.java",
    "groupTitle": "App"
  }
] });
