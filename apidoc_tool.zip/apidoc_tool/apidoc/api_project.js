define({
  "name": "投行业务管理系统",
  "version": "0.1.0",
  "description": "投行系统接口文档",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-09-12T09:16:48.811Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
